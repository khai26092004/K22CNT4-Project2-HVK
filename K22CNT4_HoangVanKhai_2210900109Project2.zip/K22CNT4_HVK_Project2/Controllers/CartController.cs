﻿using K22CNT4_HVK_TTCD1.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace K22CNT4_HVK_TTCD1.Controllers
{
    public class CartController : Controller
    {
        Entities db = new Entities();
        // GET: Cart
        public ActionResult Index()
        {
            var user = Session["User"] as K22CNT4_HVK_TTCD1.Models.NguoiDung;

            // Cập nhật lại số lượng sản phẩm trong giỏ hàng vào Session
            var cartItems = db.GioHangs.Where(g => g.Idnguoidung == user.Id).ToList();
            int cartItemCount = cartItems.Sum(item => item.soluong);
            Session["CartItemCount"] = cartItemCount; ;

            if (user != null)
            {              
                var cartWithProducts = cartItems.Select(item => new CartItemViewModel
                {
                    CartItemId = item.Id,
                    ProductId = item.Idcay,
                    ProductName = db.Cays.FirstOrDefault(p => p.Id == item.Idcay).Tencay,
                    Price = db.Cays.FirstOrDefault(p => p.Id == item.Idcay).Dongia,
                    Quantity = item.soluong,
                    TotalPrice = item.tonggiatien,
                    ProductImage = db.Cays.FirstOrDefault(p => p.Id == item.Idcay).Hinhanh
                }).ToList();

                return View(cartWithProducts);
            }
            else
            {
                return RedirectToAction("DangNhap", "Home", new { area = "" });
            }
        }



        [HttpPost]
        public ActionResult Add(int variantId, int quantity)
        {
            // Validate the quantity
            if (quantity <= 0)
            {
                ModelState.AddModelError("", "Số lượng không hợp lệ.");
                return RedirectToAction("Index", "Home");
            }

            // Find the product by its ID
            var product = db.Cays.FirstOrDefault(x => x.Id == variantId);  // Use variantId here
            if (product == null)
            {
                // Product not found
                return HttpNotFound();
            }

            // Check if the requested quantity is available in stock
            if (quantity > product.Soluong)
            {
                ModelState.AddModelError("", "Không đủ hàng trong kho.");
                return RedirectToAction("Index", "Home");
            }

            var user = Session["User"] as K22CNT4_HVK_TTCD1.Models.NguoiDung;
            // Retrieve the logged-in user from the session
           
            if (user == null)
            {        
                // If no user is logged in, redirect to login page
                return RedirectToAction("DangNhap", "Home", new { area = "" });
            }
            var userId = user.Id; // Get the user ID

            // Check if the product already exists in the user's cart
            var existingCartItem = db.GioHangs
                .FirstOrDefault(g => g.Idnguoidung == userId && g.Idcay == variantId);  // Use variantId here

            if (existingCartItem != null)
            {
                existingCartItem.soluong += quantity;
                existingCartItem.tonggiatien = existingCartItem.soluong * product.Dongia;
                db.Entry(existingCartItem).State = EntityState.Modified;
            }
            else
            {
                var newCartItem = new GioHang
                {
                    Idnguoidung = userId,
                    Idcay = variantId,  // Use variantId here
                    soluong = quantity,
                    tonggiatien = quantity * product.Dongia,
                };

                db.GioHangs.Add(newCartItem);
            }

            db.SaveChanges();
            return RedirectToAction("Index", "Cart");
        }

        // Action to delete an item from the cart
        public ActionResult Delete(int id)
        {
            var cartItem = db.GioHangs.FirstOrDefault(g => g.Id == id);
            if (cartItem != null)
            {
                db.GioHangs.Remove(cartItem); // Remove item from the cart
                db.SaveChanges();
            }

            return RedirectToAction("Index", "Cart");
        }

    }

}


